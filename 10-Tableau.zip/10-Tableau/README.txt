The data was collected using the pipeline.py script which connects to a database, accesses a 
table, queries the table contents and dump it into a CSV file.

The CSV file that contains the data itself is trending_by_time.csv.

The data was analyzed and presented into readable charts using Tableau Public, whose link
to the dashboard is provided in the Dashboard Link text file.

A description of the charts and answer to key questions can be found in the Summary pdf


